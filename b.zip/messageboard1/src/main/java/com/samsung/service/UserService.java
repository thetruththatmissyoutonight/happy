package com.samsung.service;


import com.google.common.cache.Cache;
import com.samsung.dao.UserDao;

public class UserService {

    private Logger logger = LoggerFactory.getLogger(UserService.class);

    private UserDao userDao = new UserDao();

    //邮件发送时候的缓存,token 注意其中的数据信息安全
    private static Cache<String,String> cache = CacheBuilder.newBuilder()
            .expireAfterWrite(3, TimeUnit.HOURS)//一般网站的时间设定是多少?
            .build();

    //找回密码邮件token缓存
    private static Cache<String,String> passwordCache = CacheBuilder.newBuilder()
            .expireAfterWrite(30,TimeUnit.MINUTES)
            .build();

    //操作频率的缓存时间限制
    private static Cache<String,String> activeCache = CacheBuilder.newBuilder()
            .expireAfterWrite(60,TimeUnit.SECONDS)
            .build();
    //检验用户名字
    public boolean validateUserName(String username) {
        //注意保留用户名(名人或其他的名字)
        String name = Config.get("no.signup.usernames");
        List<String> nameList = Arrays.asList(name.split(","));
        if(nameList.contains(username)) {
            return false;
        }
        return  userDao.findByUserName(username) == null;
    }



    /*用户注册*/

    public User findByEmail(String email) {
        return userDao.findByEmail(email);
    }


    public void saveNewUser(String username, String password, String email, String phone) {
        User user = new User();
        user.setUsername(username);
        user.setAvatar(User.DEFAULT_AVATAR_NAME);
        user.setEmail(email);
        user.setPhone(phone);
        user.setPassword(DigestUtils.md5Hex(Config.get("user.password.salt") + password));
        user.setState(User.USERSTATE_UNACTIVE);

        userDao.save(user);

        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                //给用户发送激活邮件
                String uuid = UUID.randomUUID().toString();
                String url = "http://www.home.com/user/active?_="+uuid;
                //放入缓存等待3个小时
                cache.put(uuid,username);

                String html ="<h3>Dear "+username+":</h3>请点击<a href='"+url+"'>该链接</a>去激活你的账号. <br> 凯盛软件";

                EmailUtil.sendHtmlEmail(email,"用户激活邮件",html);
            }
        });
        thread.start();
    }



    /*注册用户激活*/
    //根据token
    public void activeUser(String token) {
        String userName = cache.getIfPresent(token);
        if(userName == null) {
            throw new ServiceException("token无效或已过期");
        } else {
            User user = userDao.findByUserName(userName);
            if(user == null) {
                throw new ServiceException("无法找到对应的账号");
            } else {
                user.setState(User.USERSTATE_ACTIVE);
                userDao.update(user);
                cache.invalidate(token);
            }
        }
    }


    /*用户登录*/
    public User login(String username, String password, String ip) {
        User user = userDao.findByUserName(username);
        if(user != null && DigestUtils.md5Hex(Config.get("user.password.salt") + password).equals(user.getPassword())) {
            if(user.getState().equals(User.USERSTATE_ACTIVE)) {
                //记录登录日志
                LoginLog log = new LoginLog();
                log.setIp(ip);
                log.setUserId(user.getId());

                //loginLogDao.save(log);
                //loginLogDao.save(log);
                logger.info("{}登录了系统，IP：{}",username,ip);
                return user;

            } else if(User.USERSTATE_UNACTIVE.equals(user.getState())) {
                throw new ServiceException("该账号未激活");
            } else {
                throw new ServiceException("该账号已被禁用");
            }
        } else {
            throw new ServiceException("账号或密码错误");
        }
    }
    /*用户找回密码*/
    public void foundPassword(String sessionId, String type, String value) {
        if(activeCache.getIfPresent(sessionId) == null) {
            if("phone".equals(type)) {
            } else if("email".equals(type)) {
                User user = userDao.findByEmail(value);
                if(user != null) {
                    Thread thread = new Thread(new Runnable() {
                        @Override
                        public void run() {
                            String uuid = UUID.randomUUID().toString();
                            String url = "http://www.home.com/findpassword?token=" + uuid;

                            passwordCache.put(uuid,user.getUsername());
                            String html = user.getUsername()+"<br>请点击该<a href='"+url+"'>链接</a>进行找回密码操作，链接在30分钟内有效";
                            EmailUtil.sendHtmlEmail(value,"密码找回邮件",html);
                        }
                    });
                    thread.start();
                }
            }

            activeCache.put(sessionId,"xx");
        } else {
            throw new ServiceException("操作频率过快");
        }
    }

    /*通过链接获取找回密码的用户*/

    public User foundPasswordGetUserByToken(String token) {
        String username = passwordCache.getIfPresent(token);
        if(StringUtils.isEmpty(username)) {
            throw new ServiceException("token过期或错误");
        } else {
            User user = userDao.findByUserName(username);
            if(user == null) {
                throw new ServiceException("未找到对应账号");
            } else {
                return user;
            }
        }

    }

    /*重置用户的密码*/

    public void resetPassword(String id, String token, String password) {
        if(passwordCache.getIfPresent(token) == null) {
            throw new ServiceException("token过期或错误");
        } else {
            User user = userDao.findById(Integer.valueOf(id));
            user.setPassword(DigestUtils.md5Hex(Config.get("user.password.salt")+password));
            userDao.update(user);
            logger.info("{} 重置了密码",user.getUsername());
        }
    }



}
