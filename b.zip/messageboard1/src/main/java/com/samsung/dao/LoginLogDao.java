package com.samsung.dao;

import com.samsung.entity.LoginLog;
import com.samsung.util.DbHelp;

public class LoginLogDao  {

    public void save(LoginLog log) {
        String sql = "insert into t_login_log(ip,userid) values(?,?)";
        DbHelp.update(sql,log.getIp(),log.getUserId());
    }
}
